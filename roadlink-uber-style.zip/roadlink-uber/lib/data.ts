export const routes = [
  { from: "Mobile", to: "Birmingham", price: "$45", time: "3h 40m", seats: 3 },
  { from: "Mobile", to: "New Orleans", price: "$55", time: "2h 15m", seats: 2 },
  { from: "Birmingham", to: "Atlanta", price: "$65", time: "2h 25m", seats: 4 },
  { from: "Miami", to: "Orlando", price: "$49", time: "3h 20m", seats: 1 },
  { from: "Dallas", to: "Houston", price: "$59", time: "3h 35m", seats: 3 },
  { from: "Los Angeles", to: "Las Vegas", price: "$75", time: "4h 10m", seats: 2 }
];

export const testimonials = [
  { name: "Marcus Reed", city: "Atlanta, GA", text: "RoadLink helped me split the cost of a long drive and meet reliable travelers.", rating: "★★★★★" },
  { name: "Emily Carter", city: "Mobile, AL", text: "The experience felt simple, clean, and safer than posting in random groups.", rating: "★★★★★" },
  { name: "Daniel Moore", city: "Orlando, FL", text: "This is exactly what long-distance travelers need.", rating: "★★★★★" }
];
