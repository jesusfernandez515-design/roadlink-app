export default function Header() {
  return (
    <header className="header">
      <div className="container header-inner">
        <a href="/" className="logo"><span className="logo-mark">R</span><span>RoadLink</span></a>
        <nav className="nav">
          <a href="/search">Find a ride</a>
          <a href="/offer">Offer a ride</a>
          <a href="/rides">Rides</a>
          <a href="/dashboard">Dashboard</a>
          <a href="/contact">Contact</a>
        </nav>
        <a className="btn" href="/signup">Get started</a>
      </div>
    </header>
  );
}
