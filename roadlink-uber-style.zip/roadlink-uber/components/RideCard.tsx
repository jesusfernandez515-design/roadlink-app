type RideCardProps = { from: string; to: string; price: string; time: string; seats: number };

export default function RideCard({ from, to, price, time, seats }: RideCardProps) {
  return (
    <div className="card route-card">
      <div>
        <h3>{from} → {to}</h3>
        <p className="muted">Travel time: {time} · {seats} seats available</p>
        <p className="muted">Verified driver · Instant request</p>
      </div>
      <div className="price">{price}</div>
    </div>
  );
}
