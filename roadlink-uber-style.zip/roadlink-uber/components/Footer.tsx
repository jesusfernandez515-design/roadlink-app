export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="logo"><span className="logo-mark">R</span><span>RoadLink</span></div>
            <p>Modern long-distance ride sharing for drivers and passengers.</p>
            <p>Founder & CEO: Jesús Fernández Rosario</p>
          </div>
          <div><strong>Company</strong><a href="/contact">Contact</a><a href="/profile">Profile</a><a href="/dashboard">Dashboard</a></div>
          <div><strong>Rides</strong><a href="/search">Find a ride</a><a href="/offer">Offer a ride</a><a href="/rides">Available rides</a></div>
          <div><strong>Account</strong><a href="/login">Login</a><a href="/signup">Sign up</a></div>
        </div>
        <div className="footer-bottom">© 2026 RoadLink. All rights reserved.</div>
      </div>
    </footer>
  );
}
