export default function SearchBox() {
  return (
    <div className="card search-panel">
      <div className="text-center">
        <h2>Find your next ride</h2>
        <p className="muted">Search safe shared routes between cities.</p>
      </div>
      <form className="search-grid">
        <div className="field"><label>From</label><input placeholder="City or address" /></div>
        <div className="field"><label>To</label><input placeholder="City or address" /></div>
        <div className="field"><label>Date</label><input type="date" /></div>
        <div className="field"><label>Passengers</label><select><option>1 passenger</option><option>2 passengers</option><option>3 passengers</option><option>4 passengers</option></select></div>
        <button className="search-button" type="submit">Search Ride</button>
      </form>
    </div>
  );
}
