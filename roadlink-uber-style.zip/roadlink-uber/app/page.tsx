import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SearchBox from "@/components/SearchBox";
import RideCard from "@/components/RideCard";
import { routes, testimonials } from "@/lib/data";

export default function HomePage() {
  return (
    <main>
      <Header />
      <section className="hero">
        <div className="container text-center">
          <span className="badge">Safe shared rides between cities</span>
          <h1>Share the ride,<span>save on the road</span></h1>
          <p>RoadLink connects passengers and drivers traveling in the same direction. Split travel costs, ride with confidence, and make long trips more affordable.</p>
          <SearchBox />
          <div className="stats">
            <div className="card stat"><strong>50K+</strong><span className="muted">Projected rides</span></div>
            <div className="card stat"><strong>25+</strong><span className="muted">Target cities</span></div>
            <div className="card stat"><strong>24/7</strong><span className="muted">Trip requests</span></div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container text-center">
          <h2 className="title">How RoadLink works</h2>
          <p className="subtitle">A simple way to connect with people traveling in your direction.</p>
          <div className="grid steps">
            <div className="card feature"><div className="icon">1</div><h3>Search your route</h3><p className="muted">Enter your origin, destination, date, and seats.</p></div>
            <div className="card feature"><div className="icon">2</div><h3>Connect safely</h3><p className="muted">Review trip details and request your seat.</p></div>
            <div className="card feature"><div className="icon">3</div><h3>Share the ride</h3><p className="muted">Split costs and travel smarter between cities.</p></div>
          </div>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container">
          <div className="app-preview">
            <div>
              <h2 className="title">Built like a modern ride-sharing app</h2>
              <p className="subtitle" style={{ marginLeft: 0 }}>RoadLink is designed for route discovery, verified drivers, ride requests, seats, trip pricing, and future payments.</p>
              <div style={{ marginTop: 26, display: "flex", gap: 12, flexWrap: "wrap" }}>
                <a className="btn" href="/search">Find a ride</a><a className="btn secondary" href="/offer">Offer a ride</a>
              </div>
            </div>
            <div className="phone"><div className="phone-screen"><div className="map-box">📍</div><div className="driver"><div><strong>Mobile → Birmingham</strong><p className="muted">Today · 3 seats</p></div><strong>$45</strong></div><div className="driver"><div><strong>Driver verified</strong><p className="muted">4.9 rating · 120 trips</p></div><span>✅</span></div><button className="search-button" style={{ marginTop: 16 }}>Request Ride</button></div></div>
          </div>
        </div>
      </section>

      <section className="section" id="benefits">
        <div className="container text-center"><h2 className="title">Why choose RoadLink?</h2><p className="subtitle">Everything needed to make long-distance rides easier.</p>
          <div className="grid benefits">
            {[["Save money","Share fuel, tolls, and travel costs."],["Smart routes","Find people going your way."],["Driver profiles","View ratings and trip details."],["Community first","Designed for safer road travel."]].map(([title,text]) => <div className="card feature" key={title}><div className="icon">✓</div><h3>{title}</h3><p className="muted">{text}</p></div>)}
          </div>
        </div>
      </section>

      <section className="section section-soft">
        <div className="container"><div className="text-center"><h2 className="title">Popular routes</h2><p className="subtitle">Example routes for future RoadLink travelers.</p></div><div className="routes-list">{routes.slice(0,4).map((r) => <RideCard key={`${r.from}-${r.to}`} {...r} />)}</div></div>
      </section>

      <section className="section">
        <div className="container text-center"><h2 className="title">Trusted by travelers</h2><p className="subtitle">Early feedback from the RoadLink concept.</p><div className="grid testimonials">{testimonials.map((t) => <div className="card feature" key={t.name}><p style={{ color: "#f59e0b", fontWeight: 900 }}>{t.rating}</p><p className="muted" style={{ marginTop: 12 }}>“{t.text}”</p><h3 style={{ marginTop: 18 }}>{t.name}</h3><p className="muted">{t.city}</p></div>)}</div></div>
      </section>

      <section className="section"><div className="container"><div className="cta"><h2 className="title">Ready to share your ride?</h2><p className="subtitle">Join RoadLink beta and help build a better way to travel by road.</p><a className="btn secondary" style={{ marginTop: 26 }} href="/signup">Join RoadLink Beta</a></div></div></section>
      <Footer />
    </main>
  );
}
