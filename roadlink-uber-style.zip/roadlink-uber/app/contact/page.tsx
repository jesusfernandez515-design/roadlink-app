import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SearchBox from "@/components/SearchBox";
import RideCard from "@/components/RideCard";
import { routes } from "@/lib/data";

export default function Page() {
  const title = "contact";
  return (
    <main>
      <Header />
      <section className="page-hero">
        <div className="container text-center">
          <span className="badge">RoadLink</span>
          <h1 className="title" style={{ marginTop: 16 }}>{title.charAt(0).toUpperCase() + title.slice(1)}</h1>
          <p className="subtitle">This section is ready for the RoadLink app experience.</p>
        </div>
      </section>
      <section className="section">
        <div className="container">
          {title === "search" ? <SearchBox /> : title === "rides" ? <div className="routes-list">{routes.map((r) => <RideCard key={r.from + r.to} {...r} />)}</div> : title === "offer" ? <div className="card form-page"><h2>Offer a ride</h2><form className="form-stack" style={{ marginTop: 18 }}><div className="field"><label>From</label><input placeholder="City or address" /></div><div className="field"><label>To</label><input placeholder="City or address" /></div><div className="field"><label>Date</label><input type="date" /></div><div className="field"><label>Seats</label><select><option>1 seat</option><option>2 seats</option><option>3 seats</option></select></div><button className="search-button">Publish ride</button></form></div> : title === "login" || title === "signup" ? <div className="card form-page"><h2>{title === "login" ? "Login" : "Create account"}</h2><form className="form-stack" style={{ marginTop: 18 }}><div className="field"><label>Email</label><input type="email" placeholder="you@example.com" /></div><div className="field"><label>Password</label><input type="password" placeholder="Password" /></div><button className="search-button">{title === "login" ? "Login" : "Sign up"}</button></form></div> : title === "dashboard" ? <div className="grid dashboard-grid"><div className="card feature"><h3>Upcoming rides</h3><p className="muted">3 scheduled trips</p></div><div className="card feature"><h3>Earnings</h3><p className="muted">45 projected</p></div><div className="card feature"><h3>Rating</h3><p className="muted">4.9 average</p></div></div> : title === "contact" ? <div className="card form-page"><h2>Contact RoadLink</h2><form className="form-stack" style={{ marginTop: 18 }}><div className="field"><label>Name</label><input placeholder="Your name" /></div><div className="field"><label>Email</label><input type="email" placeholder="you@example.com" /></div><div className="field"><label>Message</label><textarea rows={5} placeholder="How can we help?" /></div><button className="search-button">Send message</button></form></div> : <div className="card feature text-center"><h2>RoadLink Profile</h2><p className="muted">Manage your account, trips, vehicle information, and preferences.</p></div>}
        </div>
      </section>
      <Footer />
    </main>
  );
}
