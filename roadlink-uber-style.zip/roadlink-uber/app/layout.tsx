import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "RoadLink | Shared Rides Between Cities",
  description: "RoadLink connects drivers and passengers traveling in the same direction.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
